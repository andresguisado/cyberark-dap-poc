#!/bin/bash -ex

cd "${PWD}/tests"
./test.sh
